# ZipScan MVP

This FastAPI + Celery + Redis app scans uploaded zip files for threats.

## Run locally

```bash
docker-compose up --build
```

Then visit `http://localhost:8000/docs` to upload and scan files.
