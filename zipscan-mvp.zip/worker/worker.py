from celery import Celery
import subprocess

app = Celery('tasks', broker='redis://redis:6379/0')

@app.task
def run_scan(path):
    result = subprocess.run(['clamscan', '-r', path], capture_output=True, text=True)
    return result.stdout
