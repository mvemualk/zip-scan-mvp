import os, subprocess

def scan_directory(path):
    result = subprocess.run(['clamscan', '-r', path], capture_output=True, text=True)
    return result.stdout
