from fastapi import FastAPI, UploadFile, File
from fastapi.responses import JSONResponse
import zipfile, tempfile, os, shutil, subprocess

app = FastAPI(title="ZipScan API")

@app.post("/scan")
async def scan_file(file: UploadFile = File(...)):
    with tempfile.TemporaryDirectory() as tmpdir:
        zip_path = os.path.join(tmpdir, file.filename)
        with open(zip_path, 'wb') as f:
            f.write(await file.read())
        
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(tmpdir)

        report = {}
        try:
            result = subprocess.run(['clamscan', '-r', tmpdir], capture_output=True, text=True)
            report['antivirus'] = result.stdout
        except Exception as e:
            report['antivirus'] = str(e)

        return JSONResponse({"status": "completed", "report": report})
